<?php
return [
	/**
	 * Your kraken API key
	 */
	'kraken_key'	=>	env('KRAKEN_KEY'),
	'kraken_secret'	=>	env('KRAKEN_SECRET'),

];