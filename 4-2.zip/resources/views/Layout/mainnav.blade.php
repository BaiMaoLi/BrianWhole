<nav class="st-menu st-effect">
    <span class="fa fa-times close-sidebar" id="close-sidebar"></span>
    <table class="table table-cryptic dataTable no-footer" role="grid" style="background-color:white;">
        <thead>
        <tr role="row">
            <th colspan="2" rowspan="1" style="text-align:center;">Currency <i class="fa fa-sort"></i></th>
        </tr>
        </thead>
        <tbody>
        <tr role="row">
            <td class="cointd1"><span><a href="#"><i class="cc BTC" title="BTC"></i></a></span></td>
            <td class="cointd2">
                <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> BTC</a></h6>
            </td>
        </tr>
        <tr role="row">
            <td class="cointd1"><span><a href="#"><i class="cc ETH" title="ETH"></i></a></span></td>
            <td class="cointd2">
                <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> ETH</a></h6>
            </td>
        </tr>
        <tr role="row">
            <td class="cointd1"><span><a href="#"><i class="cc LTC" title="LTC"></i></a></span></td>
            <td class="cointd2">
                <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> LTC</a></h6>
            </td>
        </tr>
        {{-- <tr role="row">
            <td><span><a href="#"><i class="cc XEM" title="XEM"></i></a></span></td>
            <td>
                <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> NEM</a></h6>
                <small class="text-muted">XEM</small>
            </td>
            <td class="text-right"><p><span>$</span> 1.11</p></td>
        </tr> --}}
        </tbody>
    </table>
</nav>
