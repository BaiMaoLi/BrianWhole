A Pen created at CodePen.io. You can find this one at https://codepen.io/pzi/pen/gPyrQX.

 A d3 line graph with additional "horizontal padding" to the chart area.