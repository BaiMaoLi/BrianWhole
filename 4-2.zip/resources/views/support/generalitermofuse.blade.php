<html>
<head>
    @include('Layout/head')
</head>
<body>
<header>
    @include('Layout/header')
</header>
<div class="container">
    <section>
        @include('Layout/siderbar')
        <article>
            <h1 style="text-decoration: underline">General Term of Use</h1><br>
            <p>To be decided.</p><br>

        </article>
    </section>
</div>
<footer class="bg-dark">
    @include('Layout/footer')
</footer>
</body>
</html>
