<html>
<head>
    @include('Layout/head')
</head>
<body>
<header>
    @include('Layout/header')
</header>
<div class="container">
    <section>
        @include('Layout/siderbar')
        <article>
            <h1 style="text-decoration: underline">WITHDRAWAL</h1><br>
            <p>ELECTRONIC FUND TRANSFER</p><br>
            <p>1. LOG-IN.</p><br>
            <p>2. Follow Below:</p>
            <p>BANK NAME:</p>
            <p>ACCOUNT NAME:</p>
            <p>BSB:</p>
            <p>ACCOUNT NO:</p><br>
            <p>3. Confirm Submission with Password.</p>
            <p>Note: Please see user agreement relating to deposit conditions & bank transfer fee.</p>

        </article>
    </section>
</div>
<footer class="bg-dark">
    @include('Layout/footer')
</footer>
</body>
</html>
