
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script src=<?php echo e(asset("assets/js/jquery.scrollbar.min.js")); ?>></script>
<script src=<?php echo e(asset("assets/plugins/modernizr/modernizr.custom.js")); ?>></script>
<script src=<?php echo e(asset("assets/plugins/classie/classie.js")); ?>></script>
<script src=<?php echo e(asset("assets/plugins/select2/select2.min.js")); ?>></script>
<script src=<?php echo e(asset("assets/plugins/dataTables/jquery.dataTables.min.js")); ?>></script>
<script src=<?php echo e(asset("assets/plugins/counter-transaction/jquery.appear.js")); ?>></script>
<script src=<?php echo e(asset("assets/plugins/counter-transaction/jquery.countTo.js")); ?>></script>
<script src=<?php echo e(asset("assets/plugins/webticker/jquery.webticker.min.js")); ?>></script>
<script src=<?php echo e(asset("assets/plugins/chartjs/Chart.bundle.js")); ?>></script>
<script src=<?php echo e(asset("assets/plugins/chartjs/utils.js")); ?>></script>
<script src=<?php echo e(asset("assets/js/charts.js")); ?>></script>
<script src=<?php echo e(asset("assets/js/custom.min.js")); ?>></script>
<script src=<?php echo e(asset("assets/js/preloader.min.js")); ?>></script>
<script src=<?php echo e(asset("assets/js/canvasjs.min.js")); ?>></script>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "255px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
