
    <title>
        Remitty - Buy/Sell Digital Currency
    </title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta charSet="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    
    
    
    <!--===============================================================================================-->
    	<link rel="icon" type="image/png" href=<?php echo e(asset("vendor/images/icons/favicon.ico")); ?>/>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/bootstrap/css/bootstrap.min.css")); ?>>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/fonts/font-awesome-4.7.0/css/font-awesome.min.css")); ?>>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/fonts/Linearicons-Free-v1.0.0/icon-font.min.css")); ?>>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/animate/animate.css")); ?>>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/css-hamburgers/hamburgers.min.css")); ?>>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/animsition/css/animsition.min.css")); ?>>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/select2/select2.min.css")); ?>>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/daterangepicker/daterangepicker.css")); ?>>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/css/util.css")); ?>>
    	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("vendor/css/main.css")); ?>>
    <!--===============================================================================================-->
    
