<footer style="margin-left:0px;">
    <div class="pull-right" >
        &copy; 2018. All Rights Reserved.
    </div>
    <div class="clearfix"></div>
</footer>
