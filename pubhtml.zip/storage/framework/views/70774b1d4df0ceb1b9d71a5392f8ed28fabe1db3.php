<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8" style="max-width:730px;">
            <div class="card">
                <div class="card-header" style="text-align:center;background-color:#64e4b0;height:55px;">
                    <a href="<?php echo e(route('remittyllc')); ?>" style="color:blue;float:left;"> &#8592; </a>
                    <?php echo e(__('Verify Your Email Address')); ?>

                    <a href="<?php echo e(route('login')); ?>" style="color:blue;float:right;"> &#8594; </a>
                </div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                    <?php echo e(__('If you did not receive the email')); ?>, <a href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__('click here to request another')); ?></a>.
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>