<?php $__env->startSection('headerpart'); ?>
   <title>Remitty | Transactions</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="right_col container" role="main">
        <div class="spacer_20 "></div>
        <div class="clearfix"></div>
        <div class="row nav nav-tabs jgjtransaction" >
                <div class=" col-md-2"></div>
                <div class="col-md-12 col-xs-12 jgjcoldiv ">
                    <table class="table jgjtranstable">
                        <thead class="thead-dark">
                            <tr>
                                <th class="jgjth"> Sender</th>
                                <th class="jgjth"> Receiver </th>
                                <th class="jgjth"> Currency </th>
                                <th class="jgjth"> Amount</th>
                                <th class="jgjth"> Date </th>
                                <th class="jgjth"> Status </th>
                            </tr>
                        </thead>
                        <tbody>
                             <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr class="table-tr" data-url="<?php echo e(url('transactions/'.$transaction->id)); ?>">
                                  <td> <?php echo e($transaction->ulastname); ?> </td>
                                  <td> <?php echo e($transaction->rlastname); ?> </td>
                                  <td> <?php echo e($transaction->currency); ?> </td>
                                  <td> <?php echo e($transaction->amount); ?> </td>
                                  <td> <?php echo e($transaction->time); ?> </td>
                                  <td> <?php echo e($transaction->status); ?> </td>
                              </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                    </table>
                </div>
                <div class=" col-md-2"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
         $('table.table').on("click", "tr.table-tr", function() {
           window.location = $(this).data("url");
           //alert($(this).data("url"));
         });
       });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>