<?php $__env->startSection('headerpart'); ?>
    <title>Remitty | ReceiverTransfer</title>
	<?php
		$senderID = Auth::id();

	?>

	<?php if(app('request')->input('phone') == null ): ?>
	<script>window.location = "<?php echo e(route('dashboard')); ?>#sendMoney";</script>
	<link href=<?php echo e(asset("assets/css/intlTelInput.css")); ?> rel="stylesheet">
	<link href=<?php echo e(asset("assets/css/demo.css")); ?> rel="stylesheet">
	<link href=<?php echo e(asset("assets/css/accounts.css")); ?> rel="stylesheet">
	<script src=<?php echo e(asset("assets/js/countries.js")); ?>></script>
	<style>
        .jgjcolorred{
          color: blue;
          font-size: large;
        }

        input::-webkit-input-placeholder {
        color: grey !important;
        }

        input:-moz-placeholder { /* Firefox 18- */
        color: grey !important;
        }

        input::-moz-placeholder {  /* Firefox 19+ */
        color: grey !important;
        }

        input:-ms-input-placeholder {
        color: grey !important;
        }

    </style>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="right_col container" role="main">
		<div class="clearfix"></div>

		<form class="jgjform row" method="post" action="<?php echo e(route('moneyTransfer.send')); ?>" onsubmit="return false;">
			<?php echo e(csrf_field()); ?>

			<div class=" col-md-1"></div>
			<div class=" col-md-2"></div>
			<div class=" col-md-6 pricing-calculator jgjcoldiv" id="corridor-calculator">
					<center><h2 style="color:blue;">Transaction Information</h2></center>
					  <div class="row" >
						<input type="hidden" class="form-control" id="senderId" name="senderId" value="<?php echo e($senderID); ?>" >
						<input type="hidden" class="form-control" id="senderId" name="senderId" value="<?php echo e($senderID); ?>" >
						  <div class="form-group col-xs-12">
							  <label for="exampleInputEmail1" class="jgjtextcolorblue">First Name <span class="jgjcolorred">*</span></label>
							  <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name" value="<?php echo e(app('request')->input('firstname')); ?>" required>
						  </div>
						  <div class="form-group col-xs-12">
							  <label for="exampleInputPassword1" class="jgjtextcolorblue">Last Name(s)<span class="jgjcolorred">*</span></label>
							  <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name" value="<?php echo e(app('request')->input('lastname')); ?>" required>
						  </div>

						  <input class="form-control jgj" id="phone" name="phone" type="hidden" value="<?php echo e(app('request')->input('phone')); ?>" >
						  <input type="hidden" class="form-control" id="city" name="city" placeholder="City" value="<?php echo e(app('request')->input('city')); ?>" >
						  <input type="hidden"class="form-control" name="country" id="country" value="<?php echo e(app('request')->input('country')); ?>" >
						  <input type="hidden" class="form-control" id="state" name="state" value="<?php echo e(app('request')->input('state')); ?>">


						   <div class="form-group col-xs-12 form-check-inline">
								  <label for="exampleInputPassword1" class="jgjtextcolorblue">Payout Method:<span class="jgjcolorred">*</span></label>
								  <select class="form-control" name="payout_method" id="payout_method_select" onchange="poSelectCheck(this);" value="<?php echo e(app('request')->input('payout_method')); ?>" required>
										<option value="deposits" >Bank deposits</option>
										<option id="mtnOption" value="mtn" <?php if(app('request')->input('payout_method') == 'mtn') echo "selected"; ?> >MTN Mobile Money Account</option>
										<option id="orangeOption" value="orange" <?php if(app('request')->input('payout_method') == 'orange') echo "selected"; ?>>ORANGE Mobile Money Account</option>
										<option value="pickup">Cash pick up(agent)</option>
								  </select>
							</div>

							<div class="form-group col-xs-12" id="admDivCheck" style="display:none;">
							  <label for="exampleInputEmail1" id="mobile_money__account_heading" class="jgjtextcolorblue">Mobile Money Account<span class="jgjcolorred">*</span></label>
							  <input type="number" class="form-control" id="mobile_money_account" name="mobile_money_account" placeholder="Mobile Money Account" value="<?php echo e(app('request')->input('mobile_money_account')); ?>">
							</div>

							<div class="form-group col-xs-12" >
							  <label for="exampleInputEmail1" class="jgjtextcolorblue">Amount to Send <span class="jgjcolorred">*</span></label>
							  <input type="number" class="form-control" id="amount" name="amount" placeholder="Amount to Send" value="<?php echo e(app('request')->input('amount')); ?>">
							</div>

							<div class="form-group col-xs-12 form-check-inline">
								<br>
								<label for="exampleInputPassword1" class="jgjtextcolorblue">Amount to Receive:</label>
							</div>
							<div class="col-xs-12 form-group amt-received">
								  <div class="col-xs-7 jgjleft">
									  <span id="amtReceived" data-bind="text: AmountTo()" class="form-control col-xs-7"></span>
								  </div>
								  <div class="col-xs-5 jgjright">
									  <select class="form-control" id="exampleFormControlSelect1" name="currency" required>

										<option value="XAF">XAF</option>
										<option value="NGN">NGN</option>
										<option value="KEX">RWF</option>
										<option value="UGX">UGX</option>
										<option value="KEX">KES</option>
										<option value="LYD">LYD</option>
										<option value="TND">TND</option>
										<option value="CEDI">CEDI</option>
										<option value="SDG">SDG</option>
										<option value="Mad">Mad</option>
										<option value="Pula">Pula</option>
										<option value="ZMK">ZMK</option>
										<option value="Rand">Rand</option>
										<option value="ERN">ERN</option>
										<option value="EGP">EGP</option>
										<option value="NGH">NGH</option>
										<option value="JMD">JMD</option>
										<option value="MUR">MUR</option>
										<option value="GHS">GHS</option>
										<option value="AOA">AOA</option>
										<option value="AFN">AFN</option>
										<option value="XPF">XPF</option>
										<option value="ZWD">ZWD</option>

									</select>
								  </div>
							</div>
							<div class="col-xs-12">
							  <div class="form-group">
								<label class="header jgjtextcolorblue">Todays exchange rate:</label>
								<div>
									<br>
								  <span class="textResultFormat">1 USD<span data-bind="text: CurrencyFromAbbv"></span> = </span><span id="exchangeRate" class="textResultFormat" data-bind="text: ExchangeRate"></span>
								  <span data-bind="text: CurrencyTo" id="currency" class="received-currency-code textResultFormat"></span>
								</div>
							  </div>
							</div>
						</div>
					 <div class="row">

						<div class="col-md-6 deliveryContainer">

						<div class="form-group col-xs-12 form-check-inline">
							  <label for="exampleInputPassword1" class="jgjtextcolorblue">Select a Payment Method:<span class="jgjcolorred">*</span></label>
							  <select class="form-control" name="payment_method" id="exampleFormControlSelect1" onchange="pSelectCheck(this);" required>
									<option value="bank">Bank Account</option>
									<option id="creditSelect" value="credit">Credit Card</option>
									<option id="debitSelect" value="debit">Debit Card</option>
							  </select>
						</div>
					</div>
					<div class="col-xs-12" id="cardDetails" style="display:none;" >
						  <div class="container" style="padding-left: 0px;">
							<div class="row">
								<div class="col-xs-12 col-md-4 col-md-offset-4" style="margin-left:0">
									<div class="panel panel-default">
										<div class="panel-heading">
											<div class="row">
												<h3 class="text-center">Payment Details</h3>
												<img class="img-responsive cc-img" src="http://www.prepbootstrap.com/Content/images/shared/misc/creditcardicons.png">
											</div>
										</div>
										<div class="panel-body">
											<form role="form">
												<div class="row">
													<div class="col-xs-12">
														<div class="form-group">
															<label style="color:black;">CARD NUMBER</label>
															<div class="input-group">
																<input type="tel" class="form-control" id="card_number" name="card_number" placeholder="Valid Card Number" />
																<span class="input-group-addon"><span class="fa fa-credit-card"></span></span>
															</div>
														</div>
													</div>
												</div>

												<div class="row">
													<div class="col-xs-7 col-md-7">
														<div class="form-group">
															<label style="color:black;"><span class="hidden-xs">EXPIRATION</span><span class="visible-xs-inline">EXP</span> DATE</label>
															<input type="tel" class="form-control" id="card_expiry" name="expiration" placeholder="MM / YY"/>
														</div>
													</div>
													<div class="col-xs-5 col-md-5 pull-right">
														<div class="form-group">
															<label style="color:black;">CV CODE</label>
															<input type="tel" class="form-control" id="cvv" name="cvv" placeholder="CVC" />
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-xs-12">
														<div class="form-group">
															<label style="color:black;">CARD OWNER</label>
															<input type="text" class="form-control" id="card_name" name="card_owner" placeholder="Card Owner Names" />
														</div>
													</div>
												</div>
											</form>
										</div>

									</div>
								</div>
							</div>
						</div>

						</div>


						<div class="col-xs-12">
						  <div class="form-group">
							<label class="header jgjtextcolorblue">Todays exchange rate:</label>
							<div>
							  <span class="textResultFormat"><h3>1 USD<span data-bind="text: CurrencyFromAbbv"></span> = </h3></h3></span><span id="exchangeRate" class="textResultFormat" data-bind="text: ExchangeRate"></span>
							   <span data-bind="text: CurrencyTo" id="currency" class="received-currency-code textResultFormat"></span>
							</div>
						  </div>
						</div>
					  </div>
					  <div class="row">
						<div class="col-md-12 text-center">
						  <div class="panel panel-default">
							<div class="panel-body">
							  <div>
								<div class="col-xs-6">
								  <h3 class="jgjtextcolorblue"><span data-bind="text: CurrencyFromSymbol">$--</span></h3>
								  <h4 class="jgjtextcolorblue">Transfer fee</h4>
								</div>
								<div class="col-xs-6">
								  <h3 class="jgjtextcolorblue"><span data-bind="text: CurrencyFromSymbol">$0</span><span data-bind="text: TotalAmount"></span></h3>
								  <h4 class="jgjtextcolorblue">Total</h4>
								</div>

							  </div>

							</div>
							 <button class="jgjsendbtn col-xs-6" type="submit" >Send Now</button>
						  </div>

						</div>
					  </div>
					</div>
				<div class=" col-md-2"></div>
			<div class=" col-md-1"></div>
		</form>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

	  <script language="javascript">
	    function poSelectCheck(nameSelect)
		{
		    console.log(nameSelect);
		    if(nameSelect){
		        mtnOptionValue = document.getElementById("mtnOption").value;
		        orangeOptionValue = document.getElementById("orangeOption").value;
		        if(mtnOptionValue == nameSelect.value || orangeOptionValue == nameSelect.value){
		            document.getElementById("admDivCheck").style.display = "block";
		            document.getElementById("mobile_money_account").required = true;
		        }
		        else{
		            document.getElementById("admDivCheck").style.display = "none";
		            document.getElementById("mobile_money_account").required = false;
		        }
		    }
		    else{
		        document.getElementById("admDivCheck").style.display = "none";
		    }
		}


	  	$(document).ready(function()
		{
		    nameSelect = document.getElementById("payout_method_select").value;
		    console.log(nameSelect);
		    if(nameSelect){
		        mtnOptionValue = document.getElementById("mtnOption").value;
		        orangeOptionValue = document.getElementById("orangeOption").value;
		        if(mtnOptionValue == nameSelect || orangeOptionValue == nameSelect){
		            document.getElementById("admDivCheck").style.display = "block";
		            document.getElementById("mobile_money_account").required = true;
		            document.getElementById("mobile_money__account_heading").innerHTML= nameSelect.value.toUpperCase()+" Mobile Money Account";
		        }
		        else{
		            document.getElementById("admDivCheck").style.display = "none";
		            document.getElementById("mobile_money_account").required = false;
		        }
		    }
		    else{
		        document.getElementById("admDivCheck").style.display = "none";
		    }
		});

		function pSelectCheck(nameSelect)
		{
		    if(nameSelect){
		        mtnOptionValue = document.getElemetById("creditSelect").value;
		        orangeOptionValue = document.getElementById("debitSelect").value;
		        if(mtnOptionValue == nameSelect.value || orangeOptionValue == nameSelect.value){
		            document.getElementById("cardDetails").style.display = "block";
		            document.getElementById("card_number").required = true;
		            document.getElementById("card_expiry").required = true;
		            document.getElementById("card_name").required = true;
		            document.getElementById("cvv").required = true;
		        }
		        else{
		            document.getElementById("cardDetails").style.display = "none";
		            document.getElementById("card_number").required = false;
		            document.getElementById("card_expiry").required = false;
		            document.getElementById("card_name").required = false;
		            document.getElementById("cvv").required = false;
		        }
		    }
		    else{
		        document.getElementById("cardDetails").style.display = "none";
		    }
		}
	    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>