<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta charset="UTF-8">
<meta name="keywords" content="">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href=<?php echo e(asset("assets/images/favicon.png")); ?> type="image/ico"/>
<link href=<?php echo e(asset("assets/plugins/bootstrap/bootstrap.min.css")); ?> rel="stylesheet">

<link href=<?php echo e(asset("assets/plugins/dataTables/jquery.dataTables.min.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/fonts/cryptocoins.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/css/simple-line-icons.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/css/font-awesome.min.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/css/font-awesome-animation.min.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/plugins/calendar/fullcalendar.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/plugins/calendar/jquery.qtip.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/plugins/select2/select2.min.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/css/custom.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("main.bd.css")); ?> rel="stylesheet">
<link id="ui-current-skin" href=<?php echo e(asset("assets/css/skin-colors/skin-yellow.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/css/media.css")); ?> rel="stylesheet">
<link href=<?php echo e(asset("assets/plugins/rickshaw/rickshaw.min.css")); ?> rel="stylesheet">
<link href="<?php echo e(asset('assets/css/loader.css')); ?>" rel="stylesheet">
<link rel='stylesheet' type='text/css' media='all' href='https://fonts.googleapis.com/css?family=Montserrat%7CMontserrat%3Aregular%2C700%2Clatin'/>
