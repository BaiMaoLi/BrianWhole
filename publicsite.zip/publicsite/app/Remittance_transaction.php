<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Remittance_transaction extends Model
{
    //
}
