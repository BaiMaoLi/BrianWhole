
    <title>
        Remitty - Buy/Sell Digital Currency
    </title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta charSet="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    {{-- <link rel="stylesheet" media="all" href={{asset("assets/core-425319481037d76fa7333f226e1af82b3e11de5875d499dc58de8a12c5aa01f7.css")}} /> --}}
    {{-- <link rel="stylesheet" media="all" href={{asset("assets/application-e007e3ee131a8a01d26dd188ae96eb884f30dafd8652135e4b8b95571aed4f06.css")}} /> --}}
    {{-- <script src={{asset("assets/jquery-f4879eb8690155de2bdcafd0967e4171fd96bdfcea8d747a3d1f771479f5689f.js")}}></script> --}}
    <!--===============================================================================================-->
    	<link rel="icon" type="image/png" href={{asset("vendor/images/icons/favicon.ico")}}/>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/bootstrap/css/bootstrap.min.css")}}>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/fonts/font-awesome-4.7.0/css/font-awesome.min.css")}}>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/fonts/Linearicons-Free-v1.0.0/icon-font.min.css")}}>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/animate/animate.css")}}>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/css-hamburgers/hamburgers.min.css")}}>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/animsition/css/animsition.min.css")}}>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/select2/select2.min.css")}}>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/daterangepicker/daterangepicker.css")}}>
    <!--===============================================================================================-->
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/css/util.css")}}>
    	<link rel="stylesheet" type="text/css" href={{asset("vendor/css/main.css")}}>
    <!--===============================================================================================-->
    {{-- <script src={{asset("assets/application-3086588e9ad0011dd729b0d2d9155226ad0e006a182e4d622505fc1fdc8a4201.js")}}></script> --}}
