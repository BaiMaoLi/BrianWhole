
<form action="_CALLBACK_URL_" method="POST" id="wecashup">

    <script async src="https://www.wecashup.com/library/MobileMoney.js" class="wecashup_button"
            data-demo
            data-sender-lang="en"
            data-sender-phonenumber=""
            data-receiver-uid="OMzI3Vx2NpdPXbNd1YDTntbhPm22"
            data-receiver-public-key="pk_test_Fv285qCdWleE6hW7"
            data-transaction-parent-uid=""
            data-transaction-receiver-total-amount="1000"
            data-transaction-receiver-reference="XVT2VBF"
            data-transaction-sender-reference="XVT2VBF"
            data-sender-firstname="Test"
            data-sender-lastname="Test"
            data-transaction-method="pull"
            data-image="https://storage.googleapis.com/wecashup/frontend/img/airfrance.png"
            data-name="Air France"
            data-crypto="true"
            data-cash="true"
            data-telecom="true"
            data-m-wallet="true"
            data-split="true"
            configuration-id="3"
            data-marketplace-mode="false"
            data-product-1-name="Billet ABJ PRS"
            data-product-1-quantity="1"
            data-product-1-unit-price="594426"
            data-product-1-reference="XVT2VBF"
            data-product-1-category="Billeterie"
            data-product-1-description="France is in the Air"
    >
    </script>
</form>
