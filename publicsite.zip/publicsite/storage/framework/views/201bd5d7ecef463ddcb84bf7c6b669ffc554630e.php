<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('Layout.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->yieldContent('headerpart'); ?>
</head>
<body class="nav-sm preloader-off developer-mode ">
	<div class="loader-container">
         <div class="sk-spinner sk-spinner-pulse"></div>
    </div>
	<div class="pace-cover"></div>
	<div id="st-container" class="st-container st-effect">
	    <div class="body">
	        <div class="main_container">
	            <?php echo $__env->make('Layout.maintopnav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	            <div style="width:100%;height:20px"></div>

				<?php echo $__env->yieldContent('content'); ?>

				 <?php echo $__env->make('Layout.mainfooter', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			 </div>
			<?php echo $__env->make('Layout.mainnav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	</div>
		 <div class="search search-main">
			 <div id="btn-search-close" class="btn btn--search-close" aria-label="Close search form">
				 <i class="fa fa-times"></i>
			 </div>
			 <form class="search__form" action="#">
				 <input class="search__input" name="search" type="search" placeholder="Hash, transactions..." autocomplete="off" autocapitalize="off" spellcheck="false"/>
				 <span class="search__info">Hit enter to search or ESC to close</span>
			 </form>
		 </div>


 	 <?php echo $__env->make('Layout.mainscript', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 <?php echo $__env->yieldContent('script'); ?>
	 <script>
      window.onload = function () {
          setTimeout(function () {
              $('.loader-container').fadeOut('slow');
          }, 100);
      }
    </script>
 	</div>
 </body>
 </html>
