<?php $__env->startSection('headerpart'); ?>
	<?php
		$senderID = Auth::id();
	?>
    <link href=<?php echo e(asset("assets/css/accounts.css")); ?> rel="stylesheet">
    <title>Remitty | Fiat to crypto</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="right_col container" role="main">
		<div class="nav nav-tabs" id="navtab1" style="background: #00007f; border:1px solid black;padding:15px;">
			 <div class="col-sm-8 col-sm-offset-2 col-xs-12" style="text-align: center;padding:0px;">
				 <div class="col-xs-12 form-group amt-received" style="padding:0px;">
 				   <span type="text" class="form-control fiatstyle3" style="" >
 					<input type="button" value="Buy" class="fiatstyle31" id="buybtn" style="left:10%;" name="buybtn">
 					<input type="button" value="Sell" class="fiatstyle31" id="sellbtn" style="right:10%;" name="sellbtn">
 			   </div>
				 <div class="col-xs-12 form-group amt-received" style="padding:0px;">
					  <div class="col-xs-4 jgjright" style="padding:0px;">
						  <span class="form-control fiatstyleleftboxleft" id="exampleFormControlSelect2"></span>
						  <select class="fiatstyle31" id="exampleFormControlSelect2" style="left:10%;" name="currency" required="">
							  <option value="BTC" class="others">USD</option>
							  <option value="LTC" class="others">EUR</option>
						 </select>
					  </div>
					   <div class="col-xs-8 jgjleft" style="text-align:right;padding:0px;">
						   <input type="text" class="form-control col-xs-7 fiatstyleleftboxright" placeholder="" >
					   </div>
				</div>
				<div class="col-xs-12 form-group amt-received" style="padding:0px;">
					 <div class="col-xs-4 jgjright" style="padding:0px;" >
						 <span class="form-control fiatstyleleftboxleft" id="exampleFormControlSelect2"></span>
						 <select class="fiatstyle31" id="exampleFormControlSelect2" style="left:10%;" name="currency" required="">
							 <option value="BTC" class="others">BTC</option>
							 <option value="LTC" class="others">LTC</option>
							 <option value="ETH" class="others">ETH</option>
						</select>
					 </div>
					  <div class="col-xs-8 jgjleft" style="text-align:right;padding:0px;">
						  <input input="text" id="amtReceived" data-bind="text: AmountTo()" class="form-control fiatstyleleftboxright"/>
					  </div>
				</div>
				<div class="col-xs-12 form-group ratebox" style="">
					<div class="row">
						<div style="width:65%;text-align:left;float:left;padding-left:10px;">
							<p style="color:white;">Rates: <sapn></span>&nbsp;</p>
							<p style="color:white;">Fees &nbsp;</p>
						</div>
						<div style="width:5%;text-align:left;float:left;">
							<p style="color:white;"> ≈ </p>
							<p style="color:white;"> ≈ </p>
						</div>
						<div style="width:30%;text-align:left;float:left;">
							<p style="color:white;"> <span style="font-size:25px;">   </span></p>
							<p style="color:white;"><span style="font-size:25px;">  </span></p>
						</div>
					</div>
					<div class="row">
						<input type="button" value="Buy" class="buysellbtn" id="buysellbtn" style="" name="buybtn">
					</div>
				</div>
				<div class="col-xs-12 form-group amt-received" style="padding:0px;">
					<input type="button" value="Next" id="nextbtn" class="fiatstyle4">
					<p style="width:100%; font-size:15px;position:absolute;top:44px;display:block;">
						<img src="<?php echo e(asset('assets/img/exchange1.png')); ?>" style="width:60px;float:right;margin-right:10%;"></p>
				</div>
			</div>
		</div>

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script>
	$("#buybtn").click(function(){
	    $("#buybtn").css('background-color','#4ac330');
		$("#sellbtn").css('background-color','transparent');
		$("#buysellbtn").css('background-color','#4ac330');
		$("#buysellbtn").attr('value', 'Buy');
	});
	$("#sellbtn").click(function(){
	    $("#sellbtn").css('background-color','#d8a31e');
		$("#buybtn").css('background-color','transparent');
		$("#buysellbtn").css('background-color','#d8a31e');
		$("#buysellbtn").attr('value', 'Sell');
	});

	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>